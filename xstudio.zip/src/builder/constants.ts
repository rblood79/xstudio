export const iconProps = {
    color: 'var(--color-gray-700)',
    stroke: 1,
    size: 21
};

export const iconEditProps = {
    color: 'var(--color-gray-300)',
    stroke: 1,
    size: 16
}; 