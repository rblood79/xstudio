/**/
import './index.css';
function User() {
    return (
        <div className="sidebar-content user">
            <h3>User</h3>
            user
        </div>
    );
}

export default User;