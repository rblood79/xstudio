/**/
import './index.css';
function Setting() {
    return (
        <div className="sidebar-content setting">
            <h3>Setting</h3>
            setting
        </div>
    );
}

export default Setting;