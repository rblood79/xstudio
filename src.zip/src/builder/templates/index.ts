/**
 * Templates Index
 *
 * Export all templates
 */

export * from "./layoutTemplates";
export { default as layoutTemplates } from "./layoutTemplates";
