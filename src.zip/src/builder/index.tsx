import { BuilderCore } from './main/BuilderCore';

function Builder() {
    return <BuilderCore />;
}

export default Builder; 