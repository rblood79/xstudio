import React from "react";
import { ElementProps } from "../../../types/integrations/supabase.types";
import { DataBinding } from "../../../types/builder/unified.types";
import { EventEngine } from "../../../utils/events/eventEngine";

/**
 * Preview에서 사용하는 Element 타입
 */
export interface PreviewElement {
  id: string;
  customId?: string; // custom_id from database (e.g., button_1, table_1)
  tag: string;
  props: ElementProps;
  text?: string;
  parent_id?: string | null;
  page_id?: string | null; // Layout element면 null
  order_num?: number;
  dataBinding?: DataBinding;
  deleted?: boolean;
  // Layout/Slot System 필드
  layout_id?: string | null; // Layout에 속한 요소면 Layout ID
  slot_name?: string | null; // Page 요소가 들어갈 Slot 이름
}

/**
 * 렌더링 컨텍스트 - 모든 렌더러에 전달되는 공통 데이터
 */
export interface RenderContext {
  elements: PreviewElement[];
  updateElementProps: (id: string, props: Record<string, unknown>) => void;
  setElements: (elements: PreviewElement[]) => void;
  eventEngine: EventEngine;
  projectId?: string;
  renderElement: (el: PreviewElement, key?: string) => React.ReactNode;
  // Layout/Slot System 필드
  editMode?: "page" | "layout"; // 현재 편집 모드
}

/**
 * 컴포넌트 렌더러 인터페이스
 */
export interface ComponentRenderer {
  canRender(tag: string): boolean;
  render(element: PreviewElement, context: RenderContext): React.ReactNode;
}

/**
 * 이벤트 핸들러 타입
 */
export type EventHandlerMap = Record<string, (e: Event) => void>;

/**
 * postMessage 타입들
 */
export interface PreviewMessage {
  type: string;
  [key: string]: unknown;
}

export interface UpdateElementsMessage extends PreviewMessage {
  type: "UPDATE_ELEMENTS";
  elements: PreviewElement[];
  // ⭐ Layout/Slot System: Page 정보 포함 (초기 로드 시 Layout 렌더링용)
  pageInfo?: {
    pageId: string | null;
    layoutId: string | null;
  };
}

export interface UpdateElementPropsMessage extends PreviewMessage {
  type: "UPDATE_ELEMENT_PROPS";
  elementId: string;
  props: Record<string, unknown>;
  merge?: boolean;
}

export interface DeleteElementsMessage extends PreviewMessage {
  type: "DELETE_ELEMENTS";
  elementIds: string[];
}

export interface DeleteElementMessage extends PreviewMessage {
  type: "DELETE_ELEMENT";
  elementId: string;
}

export interface ThemeVarsMessage extends PreviewMessage {
  type: "THEME_VARS";
  vars: Array<{ cssVar: string; value: string }>;
}

export interface UpdateThemeTokensMessage extends PreviewMessage {
  type: "UPDATE_THEME_TOKENS";
  styles: Record<string, string>;
}

export interface AddColumnElementsMessage extends PreviewMessage {
  type: "ADD_COLUMN_ELEMENTS";
  payload: {
    tableId: string;
    tableHeaderId: string;
    columns: Array<{
      id: string;
      tag: string;
      page_id: string;
      parent_id: string;
      order_num: number;
      props: Record<string, unknown>;
    }>;
  };
}

export interface NavigateToPageMessage extends PreviewMessage {
  type: "NAVIGATE_TO_PAGE";
  payload: {
    path: string;
    replace?: boolean;
  };
}

export interface SetDarkModeMessage extends PreviewMessage {
  type: "SET_DARK_MODE";
  isDark: boolean;
}

export interface SetEditModeMessage extends PreviewMessage {
  type: "SET_EDIT_MODE";
  mode: "page" | "layout";
}

/**
 * Layout/Slot System: Page 정보 업데이트 메시지
 * Page가 변경될 때 해당 Page의 layout_id를 Preview에 전달
 */
export interface UpdatePageInfoMessage extends PreviewMessage {
  type: "UPDATE_PAGE_INFO";
  pageId: string | null;
  layoutId: string | null;
}

export interface ElementSelectedMessage extends PreviewMessage {
  type: "ELEMENT_SELECTED";
  elementId: string;
  isMultiSelect?: boolean;
  payload: {
    rect: {
      top: number;
      left: number;
      width: number;
      height: number;
    };
    props: Record<string, unknown>;
    tag: string;
    style?: React.CSSProperties;
    computedStyle?: Partial<React.CSSProperties>;
  };
}

export interface ElementsDragSelectedMessage extends PreviewMessage {
  type: "ELEMENTS_DRAG_SELECTED";
  elementIds: string[];
}

export type MessageType =
  | UpdateElementsMessage
  | UpdateElementPropsMessage
  | DeleteElementsMessage
  | DeleteElementMessage
  | ThemeVarsMessage
  | UpdateThemeTokensMessage
  | AddColumnElementsMessage
  | NavigateToPageMessage
  | SetDarkModeMessage
  | SetEditModeMessage
  | UpdatePageInfoMessage
  | ElementSelectedMessage
  | ElementsDragSelectedMessage;
