export { PagesTab } from "./PagesTab";
export { default } from "./PagesTab";
