/**/
import './index.css';
function Dataset() {
    return (
        <div className="sidebar-content dataset">
            <h3>Dataset</h3>
            dataset
        </div>
    );
}

export default Dataset;