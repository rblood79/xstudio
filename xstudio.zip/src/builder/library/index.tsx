/**/
import './index.css';
function Library() {
    return (
        <div className="sidebar-content library">
            <h3>Library</h3>
            library
        </div>
    );
}

export default Library;