/* src/builder/monitor/index.tsx */
/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useState, useEffect } from "react";
import "./index.css";
import { useMemoryMonitor } from "../hooks/useMemoryMonitor";
import { saveService } from "../../services/save/saveService";
import type {
  PerformanceMetrics,
  ValidationError,
} from "../../services/save/saveService";
import { useStore } from "../stores";
import Table from "../components/Table";

interface HistoryLog {
  id: string; // Table requires id field
  timestamp: string;
  canUndo: string;
  canRedo: string;
  currentIndex: number;
  totalEntries: number;
  pageId: string;
}

export const Monitor: React.FC = () => {
  const { stats, statusMessage, optimizeMemory } = useMemoryMonitor();
  const [saveMetrics, setSaveMetrics] = useState<PerformanceMetrics | null>(
    null
  );
  const [validationErrors, setValidationErrors] = useState<ValidationError[]>(
    []
  );
  const [saveStatusMessage, setSaveStatusMessage] = useState<string>("");
  const [activeTab, setActiveTab] = useState<"memory" | "save" | "history">(
    "memory"
  );
  const [historyLogs, setHistoryLogs] = useState<HistoryLog[]>([]);

  // History state from store
  const historyInfo = useStore((state) => state.historyInfo);
  const currentPageId = useStore((state) => state.currentPageId);

  // SaveService 메트릭 업데이트
  useEffect(() => {
    const updateSaveMetrics = () => {
      const metrics = saveService.getPerformanceMetrics();
      const errors = saveService.getValidationErrors();
      const statusMsg = saveService.getStatusMessage();
      setSaveMetrics(metrics);
      setValidationErrors(errors);
      setSaveStatusMessage(statusMsg);
    };

    // 초기 로드
    updateSaveMetrics();

    // 5초마다 업데이트
    const interval = setInterval(updateSaveMetrics, 5000);
    return () => clearInterval(interval);
  }, []);

  // History 정보 업데이트
  useEffect(() => {
    if (historyInfo) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setHistoryLogs((prev) => {
        const newLog: HistoryLog = {
          id: `${Date.now()}-${Math.random()}`, // Unique ID for Table
          timestamp: new Date().toLocaleTimeString(),
          canUndo: historyInfo.canUndo ? "Yes" : "No",
          canRedo: historyInfo.canRedo ? "Yes" : "No",
          currentIndex: historyInfo.currentIndex,
          totalEntries: historyInfo.totalEntries,
          pageId: currentPageId || "None",
        };
        // 최근 50개만 유지
        const updated = [...prev, newLog];
        return updated.slice(-50);
      });
    }
  }, [historyInfo, currentPageId]);

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  const resetSaveMetrics = () => {
    saveService.resetMetrics();
    saveService.clearValidationErrors();
    setSaveMetrics(saveService.getPerformanceMetrics());
    setValidationErrors([]);
  };

  const clearHistoryLogs = () => {
    setHistoryLogs([]);
  };

  const totalSkips = saveMetrics
    ? saveMetrics.skipCounts.preview + saveMetrics.skipCounts.validation
    : 0;

  const successRate =
    saveMetrics && saveMetrics.saveOperations > 0
      ? (
          ((saveMetrics.saveOperations - validationErrors.length) /
            saveMetrics.saveOperations) *
          100
        ).toFixed(1)
      : "100.0";

  return (
    <>
      <div className="header">
        <div className="tabs">
          <button
            className={activeTab === "memory" ? "tab active" : "tab"}
            onClick={() => setActiveTab("memory")}
          >
            Memory Monitor
          </button>
          <button
            className={activeTab === "save" ? "tab active" : "tab"}
            onClick={() => setActiveTab("save")}
          >
            Save Monitor
          </button>
          <button
            className={activeTab === "history" ? "tab active" : "tab"}
            onClick={() => setActiveTab("history")}
          >
            History
          </button>
        </div>
        <div className="actions">
          {activeTab === "memory" && (
            <button onClick={optimizeMemory}>memory optimization</button>
          )}
          {activeTab === "save" && (
            <button onClick={resetSaveMetrics}>reset metrics</button>
          )}
          {activeTab === "history" && (
            <button onClick={clearHistoryLogs}>clear logs</button>
          )}
        </div>
      </div>
      <div className="contents">
        {activeTab === "memory" ? (
          <div className="monitor">
            {stats ? (
              <>
                <ul className="stats">
                  <li>Total Entries: {stats.totalEntries}</li>
                  <li>Command Count: {stats.commandCount}</li>
                  <li>Cache Size: {stats.cacheSize}</li>
                  <li>
                    Estimated Usage: {formatBytes(stats.estimatedMemoryUsage)}
                  </li>
                  <li>
                    Compression Ratio:{" "}
                    {(stats.compressionRatio * 100).toFixed(1)}%
                  </li>
                  <li>Recommendation: {stats.recommendation}</li>
                </ul>
                {statusMessage && (
                  <div className="status-message">
                    <strong>상태:</strong> {statusMessage}
                  </div>
                )}
              </>
            ) : (
              <li>Loading memory stats...</li>
            )}
          </div>
        ) : activeTab === "save" ? (
          <div className="monitor">
            {saveMetrics ? (
              <>
                <ul className="stats">
                  <li>Save Operations: {saveMetrics.saveOperations}</li>
                  <li>
                    Average Time: {saveMetrics.averageSaveTime.toFixed(2)}ms
                  </li>
                  <li>Success Rate: {successRate}%</li>
                  <li>Preview Skips: {saveMetrics.skipCounts.preview}</li>
                  <li>Validation Skips: {saveMetrics.skipCounts.validation}</li>
                  <li>Total Skips: {totalSkips}</li>
                </ul>
                {saveStatusMessage && (
                  <div className="status-message">
                    <strong>상태:</strong> {saveStatusMessage}
                  </div>
                )}

                {validationErrors.length > 0 && (
                  <div className="validation-errors">
                    <h4>Validation Errors ({validationErrors.length})</h4>
                    <Table
                      data={
                        validationErrors.slice(-10).map((error, index) => ({
                          id: `${error.elementId}-${index}`,
                          elementId: error.elementId,
                          field: error.field,
                          message: error.message,
                          timestamp: error.timestamp.toLocaleTimeString(),
                        })) as any
                      }
                      columns={
                        [
                          {
                            key: "elementId",
                            label: "Element ID",
                            allowsSorting: true,
                          },
                          { key: "field", label: "Field", allowsSorting: true },
                          {
                            key: "message",
                            label: "Message",
                            allowsSorting: false,
                          },
                          {
                            key: "timestamp",
                            label: "Time",
                            allowsSorting: true,
                          },
                        ] as any
                      }
                      paginationMode="pagination"
                      itemsPerPage={5}
                      height={200}
                      heightMode="fixed"
                      rowHeight={35}
                    />
                    {validationErrors.length > 10 && (
                      <p className="more-errors">
                        ... and {validationErrors.length - 10} more errors
                      </p>
                    )}
                  </div>
                )}

                {saveMetrics.saveOperations === 0 && (
                  <p className="no-data">
                    No save operations recorded yet. Start editing elements to
                    see metrics.
                  </p>
                )}
              </>
            ) : (
              <li>Loading save metrics...</li>
            )}
          </div>
        ) : (
          <div className="monitor">
            {historyLogs.length > 0 ? (
              <>
                <ul className="stats">
                  <li>Current Index: {historyInfo?.currentIndex ?? -1}</li>
                  <li>Total Entries: {historyInfo?.totalEntries ?? 0}</li>
                  <li>Can Undo: {historyInfo?.canUndo ? "Yes" : "No"}</li>
                  <li>Can Redo: {historyInfo?.canRedo ? "Yes" : "No"}</li>
                  <li>
                    Page ID:{" "}
                    {currentPageId ? currentPageId.slice(0, 8) + "..." : "None"}
                  </li>
                  <li>Log Entries: {historyLogs.length}</li>
                </ul>

                <div className="validation-errors">
                  <Table
                    data={historyLogs.slice(-20).reverse() as any}
                    columns={
                      [
                        {
                          key: "currentIndex",
                          label: "Index",
                          allowsSorting: true,
                        },
                        {
                          key: "totalEntries",
                          label: "Entries",
                          allowsSorting: true,
                        },
                        { key: "canUndo", label: "Undo", allowsSorting: false },
                        { key: "canRedo", label: "Redo", allowsSorting: false },
                        {
                          key: "timestamp",
                          label: "Time",
                          allowsSorting: true,
                        },
                      ] as any
                    }
                    paginationMode="pagination"
                    itemsPerPage={10}
                    height={300}
                    heightMode="fixed"
                    rowHeight={35}
                  />
                  {historyLogs.length > 20 && (
                    <p className="more-errors">
                      ... and {historyLogs.length - 20} more logs
                    </p>
                  )}
                </div>
              </>
            ) : (
              <p className="no-data">
                No history logs yet. Start editing to see history changes.
              </p>
            )}
          </div>
        )}
      </div>
    </>
  );
};
